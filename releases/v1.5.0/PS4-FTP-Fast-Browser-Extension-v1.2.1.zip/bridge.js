const HOST = "com.narawit.ps4ftpfast";
const EXT_RE = /\.(pkg|zip|rar|7z|iso|bin|pup|img|tar|gz|xz|exe|msi|mp4|mkv|001|part\d+)($|[?#&])/i;
const MIN_AUTO_BYTES = 10 * 1024 * 1024; // 10 MB

const handledIds = new Set();
const recentUrls = new Map();

async function isAutoCatchEnabled() {
  try {
    const data = await chrome.storage.local.get({ autoCatch: true });
    return data.autoCatch !== false;
  } catch {
    return true;
  }
}

async function renderBadge(enabled) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color: enabled ? "#0070D1" : "#4B5563" });
    await chrome.action.setBadgeText({ text: enabled ? "ON" : "OFF" });
    await chrome.action.setTitle({
      title: enabled
        ? "PS4 FTP Fast · Auto-Catch ON (click to pause)"
        : "PS4 FTP Fast · Auto-Catch OFF (click to enable)"
    });
  } catch {}
}

async function flashBadge(text, color) {
  try {
    await chrome.action.setBadgeBackgroundColor({ color });
    await chrome.action.setBadgeText({ text });
    setTimeout(async () => {
      await renderBadge(await isAutoCatchEnabled());
    }, 2600);
  } catch {}
}

chrome.runtime.onInstalled.addListener(async () => {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "send",
      title: "Download with PS4 FTP Fast",
      contexts: ["link"],
      targetUrlPatterns: ["http://*/*", "https://*/*"]
    });
  });
  await renderBadge(await isAutoCatchEnabled());
});

chrome.runtime.onStartup.addListener(async () => {
  await renderBadge(await isAutoCatchEnabled());
});

chrome.action.onClicked.addListener(async () => {
  const next = !(await isAutoCatchEnabled());
  await chrome.storage.local.set({ autoCatch: next });
  await renderBadge(next);
});

async function sendToDesktop(url, autoStart, filename) {
  const payload = { url, autoStart: !!autoStart };
  if (filename) payload.filename = filename;
  const reply = await chrome.runtime.sendNativeMessage(HOST, payload);
  if (!reply?.ok) throw new Error("Desktop app unavailable");
  return reply;
}

chrome.contextMenus.onClicked.addListener(async (info) => {
  if (info.menuItemId !== "send" || !info.linkUrl) return;
  try {
    await sendToDesktop(info.linkUrl, true, "");
    await flashBadge("OK", "#10B981");
  } catch {
    await flashBadge("!", "#EF4444");
    await chrome.action.setTitle({ title: "PS4 FTP Fast · Check desktop bridge registration" });
  }
});

function shouldCatch(item, suggestedName) {
  const targetUrl = item.finalUrl || item.url || "";
  if (!/^https?:\/\//i.test(targetUrl)) return false;
  if (item.fileSize && item.fileSize >= MIN_AUTO_BYTES) return true;
  if (suggestedName && EXT_RE.test(suggestedName)) return true;
  if (item.filename && EXT_RE.test(item.filename)) return true;
  let decoded = targetUrl;
  try { decoded = decodeURIComponent(targetUrl); } catch {}
  return EXT_RE.test(decoded);
}

function cleanBaseName(pathStr) {
  if (!pathStr) return "";
  const parts = pathStr.replace(/\\/g, "/").split("/");
  return parts[parts.length - 1] || "";
}

async function interceptDownload(item, suggestedName) {
  if (!item || handledIds.has(item.id)) return;
  const targetUrl = item.finalUrl || item.url || "";
  if (!shouldCatch(item, suggestedName)) return;
  if (!(await isAutoCatchEnabled())) return;

  const now = Date.now();
  const prev = recentUrls.get(targetUrl);
  if (prev && now - prev < 2500) return;

  handledIds.add(item.id);
  recentUrls.set(targetUrl, now);
  if (recentUrls.size > 50) {
    for (const [k, t] of recentUrls) if (now - t > 10000) recentUrls.delete(k);
  }

  try { await chrome.downloads.pause(item.id); } catch {}
  try {
    const name = cleanBaseName(suggestedName || item.filename || "");
    await sendToDesktop(targetUrl, true, name);
    try { await chrome.downloads.cancel(item.id); } catch {}
    try { await chrome.downloads.erase({ id: item.id }); } catch {}
    await flashBadge("OK", "#10B981");
  } catch {
    handledIds.delete(item.id);
    try { await chrome.downloads.resume(item.id); } catch {}
    await flashBadge("!", "#EF4444");
  }
}

chrome.downloads.onCreated.addListener((item) => {
  void interceptDownload(item, "");
});

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  suggest();
  void interceptDownload(item, item.filename || "");
});
